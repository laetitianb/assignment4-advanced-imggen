import torch, torch.nn as nn

class ConvBlock(nn.Module):
    def __init__(self,in_ch,out_ch):
        super().__init__(); self.net=nn.Sequential(
            nn.Conv2d(in_ch,out_ch,3,padding=1),nn.GroupNorm(4,out_ch),nn.SiLU(),
            nn.Conv2d(out_ch,out_ch,3,padding=1),nn.GroupNorm(4,out_ch),nn.SiLU())
    def forward(self,x): return self.net(x)

class TinyUNet(nn.Module):
    def __init__(self,in_ch=1,base=32):
        super().__init__()
        self.enc1=ConvBlock(in_ch,base)
        self.down1=nn.Conv2d(base,base,4,stride=2,padding=1)
        self.enc2=ConvBlock(base,base*2)
        self.down2=nn.Conv2d(base*2,base*2,4,stride=2,padding=1)
        self.mid=ConvBlock(base*2,base*2)
        self.up1=nn.ConvTranspose2d(base*2,base*2,4,stride=2,padding=1)
        self.dec1=ConvBlock(base*2,base)
        self.up2=nn.ConvTranspose2d(base,base,4,stride=2,padding=1)
        self.out=nn.Conv2d(base,in_ch,1)
    def forward(self,x,t_embed=None):
        x1=self.enc1(x); x2=self.enc2(self.down1(x1)); xm=self.mid(self.down2(x2))
        xu=self.up1(xm); xd=self.dec1(xu); xu2=self.up2(xd); return self.out(xu2)

class TinyEBM(nn.Module):
    def __init__(self,in_ch=1,base=32):
        super().__init__()
        self.net=nn.Sequential(
            nn.Conv2d(in_ch,base,3,padding=1),nn.SiLU(),
            nn.Conv2d(base,base,3,padding=1),nn.SiLU(),
            nn.AvgPool2d(2),
            nn.Conv2d(base,base*2,3,padding=1),nn.SiLU(),
            nn.AvgPool2d(2),
            nn.Flatten(),
            nn.Linear(base*2*7*7,64),nn.SiLU(),
            nn.Linear(64,1))
    def forward(self,x): return self.net(x).squeeze(-1)
