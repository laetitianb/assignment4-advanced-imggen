
import torch, numpy as np
from PIL import Image
from .models import TinyUNet, TinyEBM
from .utils import seed_all

def _to_grid(t, nrow=4):
    x = t.detach().cpu().float()
    x = (x - x.min()) / (x.max() - x.min() + 1e-8)
    b,c,h,w = x.shape
    ncol = (b + nrow - 1)//nrow
    grid = torch.zeros(c, nrow*h, ncol*w)
    for i in range(b):
        r = i//ncol; cidx = i%ncol
        grid[:, r*h:(r+1)*h, cidx*w:(cidx+1)*w] = x[i]
    grid = (grid.clamp(0,1)*255).byte().permute(1,2,0).numpy()
    if grid.shape[2]==1: grid = np.squeeze(grid,2)
    return grid

def save_samples(tensor, path, nrow=4):
    grid = _to_grid(tensor, nrow=nrow)
    Image.fromarray(grid).save(path)

class DDPM:
    def __init__(self, timesteps=1000, beta_start=1e-4, beta_end=0.02, img_size=28, channels=1, seed=42):
        seed_all(seed)
        self.timesteps = timesteps; self.img_size = img_size; self.channels = channels
        self.device = "cuda" if torch.cuda.is_available() else "cpu"
        self.model = TinyUNet(in_ch=channels).to(self.device).eval()
        betas = torch.linspace(beta_start, beta_end, timesteps).to(self.device)
        alphas = 1.0 - betas
        self.alphas_cumprod = torch.cumprod(alphas, dim=0)
        self.sqrt_one_minus_alphas_cumprod = torch.sqrt(1.0 - self.alphas_cumprod)
        self.betas = betas; self.alphas = alphas
    @torch.no_grad()
    def p_sample(self, x, t):
        eps = self.model(x, None)
        beta_t = self.betas[t]; alpha_t = self.alphas[t]
        mean = (1.0/torch.sqrt(alpha_t))*(x - (beta_t/self.sqrt_one_minus_alphas_cumprod[t]) * eps)
        return mean + torch.sqrt(beta_t) * torch.randn_like(x) if t>0 else mean
    @torch.no_grad()
    def sample(self, batch_size=16):
        x = torch.randn(batch_size, self.channels, self.img_size, self.img_size, device=self.device)
        for t in reversed(range(self.timesteps)):
            x = self.p_sample(x, t)
        return x

class EBMSampler:
    def __init__(self, steps=200, step_size=0.1, noise_scale=0.01, img_size=28, channels=1, seed=42):
        seed_all(seed)
        self.steps=steps; self.step_size=step_size; self.noise_scale=noise_scale
        self.img_size=img_size; self.channels=channels
        self.device = "cuda" if torch.cuda.is_available() else "cpu"
        self.model = TinyEBM(in_ch=channels).to(self.device).eval()
    def sample(self, batch_size=16, init="noise"):
        if init=="zeros":
            x = torch.zeros(batch_size, self.channels, self.img_size, self.img_size, device=self.device, requires_grad=True)
        else:
            x = torch.randn(batch_size, self.channels, self.img_size, self.img_size, device=self.device, requires_grad=True)
        for _ in range(self.steps):
            x.grad=None
            energy=self.model(x).sum()
            energy.backward()
            with torch.no_grad():
                x = x - self.step_size * x.grad
                x = x + self.noise_scale * torch.randn_like(x)
                x = x.clamp(-3,3)
                x.requires_grad_(True)
        return x.detach()
