from fastapi import FastAPI
from pydantic import BaseModel
import torch
from .inference import DDPM, EBMSampler, save_samples
app=FastAPI(title="Assignment 4: Image Generation API")
ddpm=None; ebm=None
class GenRequest(BaseModel):
    batch_size:int=8; img_size:int=28; steps:int|None=None; step_size:float|None=None; noise_scale:float|None=None
@app.get("/health")
def health(): return {"status":"ok"}
@app.post("/generate/diffusion")
def generate_diffusion(req:GenRequest):
    global ddpm
    if ddpm is None or ddpm.img_size!=req.img_size: ddpm=DDPM(img_size=req.img_size,timesteps=100,channels=1)
    with torch.no_grad(): samples=ddpm.sample(batch_size=req.batch_size)
    out="/tmp/diffusion_samples.png"; save_samples(samples,out,4); return {"message":"diffusion ok","saved":out}
@app.post("/generate/ebm")
def generate_ebm(req:GenRequest):
    global ebm
    if ebm is None or ebm.img_size!=req.img_size: ebm=EBMSampler(steps=req.steps or 120, step_size=req.step_size or 0.08, noise_scale=req.noise_scale or 0.01, img_size=req.img_size)
    samples=ebm.sample(batch_size=req.batch_size); out="/tmp/ebm_samples.png"; save_samples(samples,out,4); return {"message":"ebm ok","saved":out}
